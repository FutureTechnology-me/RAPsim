var az_p=location.protocol=='https:'?'https://':'http://';
var az_url=location.protocol=='https:'?az_us:az_u;
var az_r=Math.floor(Math.random()*99999999);
if (!document.phpAds_used) document.phpAds_used = ',';

function az_adjs(z,n)
{
  if (z>-1) {
    var az="<"+"script language='JavaScript' type='text/javascript' ";
    az+="src='"+az_p + az_url + az_js + "?n="+n+"&zoneid="+z;
    az+="&source="+az_channel+"&exclude="+document.phpAds_used+"&r="+az_r;
    az+="&mmm_fo="+(document.mmm_fo)?'1':'0';
    if (window.location) az+="&loc="+escape(window.location);
    if (document.referrer) az+="&referer="+escape(document.referrer);
    az+="'><"+"/script>";
    document.write(az);
  }
}
